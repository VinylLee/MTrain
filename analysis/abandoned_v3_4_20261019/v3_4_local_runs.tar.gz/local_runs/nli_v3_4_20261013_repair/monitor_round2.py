"""Read-only experiment observer with atomic local status files; never generates data."""
import json,os,subprocess,sys,time
from collections import Counter
from pathlib import Path
from nli_v3_4.data import sha256,write_json
root=Path(sys.argv[1]).resolve()
identity=json.loads((root/'driver.json').read_text());pid=identity['pid']
manifest_path=Path(identity['command'][identity['command'].index('--manifest')+1])
manifest=json.loads(manifest_path.read_text());last_integrity=0;integrity={}
cache={}
while True:
 now=time.time()
 try:alive='run_nli_v3_4_development.py' in Path(f'/proc/{pid}/cmdline').read_bytes().decode()
 except (FileNotFoundError,PermissionError):alive=False
 if now-last_integrity>=3600:
  snap=json.loads((root/'code_snapshot_manifest.json').read_text())
  integrity={'checked_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime(now)),
   'code_snapshot_unchanged':all(sha256(root/'code_snapshot'/p)==h for p,h in snap['files'].items()),
   'frozen_inputs_unchanged':all(sha256(i['input'])==i['sha256'] for i in manifest['datasets'].values())}
  last_integrity=now
 jobs={}
 for arm in ('v3_4','v3_3','v3_3_original'):
  for d in ('train','snli','mnlim','mnlimm','sick'):
   p=root/arm/(d+'.generation_log.jsonl');key=f'{arm}/{d}'
   if not p.exists():jobs[key]={'state':'pending','accepted_followups':0};continue
   stamp=(p.stat().st_mtime_ns,p.stat().st_size)
   if key not in cache or cache[key][0]!=stamp:
    raw=p.read_text();lines=raw.splitlines() if raw.endswith('\n') else raw.rsplit('\n',1)[0].splitlines()
    try:logs=[json.loads(l) for l in lines if l.strip()]
    except json.JSONDecodeError as exc:
     jobs[key]={'journal_error':str(exc)};continue
    rows=[e['row'] for e in logs if e.get('row')]
    sources={r['pair_id']:r['label'] for r in map(json.loads,(manifest_path.parent/'development_sources'/(d+'.jsonl')).read_text().splitlines())}
    inv_counts=Counter(sources[r['pair_id']] for r in rows if r['mr_type']=='inv')
    cache[key]=(stamp,{'requests':len(logs),'accepted_followups':len(rows),
      'labels':dict(Counter(r['label'] for r in rows)),'invariant_original_label_counts':dict(inv_counts)})
   jobs[key]=cache[key][1]
 summary=json.loads((root/'status.json').read_text()) if (root/'status.json').exists() else {}
 write_json(root/'progress_live.json',{'checked_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime(now)),
  'driver_pid':pid,'driver_alive':alive,'state':summary.get('state'),'jobs':jobs,
  'integrity':integrity,'scientific_acceptance_verified':False,'local_only':True})
 if not alive:break
 time.sleep(60)
