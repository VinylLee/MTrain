import json
from pathlib import Path
from openai import OpenAI
from nli_v3_4 import core
from nli_v3_4.data import read_jsonl,write_json
from nli_v3_4.protocol import parse_judgments
root=Path('local_runs/nli_v3_4_20261013_repair/smoke_round2_calibrated')
sources={r['pair_id']:r for r in read_jsonl('local_runs/nli_v3_4_20261012/development/development_sources/mnlim.jsonl')}
cases=[
 (766,'synonym_replacement',['They were utilizing cheat codes so they had unlimited bullets.'],[True]),
 (7311,'voice_switch',['He immediately repulsed me, and I still feel the same way about him.'],[True]),
 (7279,'synonym_replacement',['Professor Rogers has served him as a clerk.'],[False]),
 (8589,'synonym_replacement',['Distant from the kids'],[False]),
 (7955,'pronoun_substitution',['The instructors are really good at helping, and they are always available.'],[False]),
]
client=OpenAI(api_key='local',base_url='http://127.0.0.1:1234/v1',timeout=120,max_retries=0)
results=[]
for pair_id,op,candidates,expected in cases:
 source=sources[pair_id];trace={}
 verdicts=core.judge_current(client,source,op,candidates,trace,max_tokens=650)
 raw=trace
 chosen=core.legacy.choose_candidate(candidates,verdicts,source,op)
 generated=[{'hypothesis':c,'target_label':core.target_label(source,op)} for c in candidates]
 deterministic=core.parse_candidates(json.dumps(generated),source,op)
 result={'pair_id':pair_id,'operation':op,'source':source,'candidates':candidates,'expected_method_acceptance':expected,
   'raw_judgment':raw,'judgments':verdicts,'same_model_accepted':bool(chosen),'parser_candidates':deterministic,
   'method_accepted':bool(chosen and chosen[0] in deterministic)}
 results.append(result);write_json(root/'results.json',{'stage':'development_interface_smoke','not_formal_trial':True,
  'contract_sha256':core.fingerprint(),'cases':results});print(pair_id,result['method_accepted'],expected,flush=True)
