"""Launch an immutable local development snapshot without overwriting any output."""
import argparse,json,os,shutil,subprocess,sys
from pathlib import Path
from nli_v3_4 import core
from nli_v3_4.data import sha256,write_json
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args()
root=Path('/home/ubuntu/MTrain');repair=root/'local_runs/nli_v3_4_20261013_repair'
previous=repair/'pilot_round2';out=a.output.resolve();snapshot=out/'code_snapshot'
if out.exists():raise FileExistsError(out)
prior=json.loads((previous/'code_snapshot_manifest.json').read_text())
assert prior['contract_sha256']==core.fingerprint(),'This engineering correction must not change round-2 prompts.'
files=sorted(set(prior['files']) | {str(p) for p in Path('nli_v3_4').glob('*.py')} | {'tests/test_nli_development_processes.py'})
for rel in files:
 dest=snapshot/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/rel,dest)
write_json(out/'code_snapshot_manifest.json',{'local_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True,cwd=root).strip(),'files':{rel:sha256(root/rel) for rel in files},'contract_sha256':core.fingerprint(),'remote_push':False,'same_prompt_round':2,'prior_engineering_preflights':[str(previous),str(repair/'pilot_round2_corrected')],'existing_rule_enforced':'specific retained antecedent, NP replacement, gender and number', 'scheduler_policy':'balance_attempts_within_target_label_and_MR_v2','interruption_propagation_verified':True})
write_json(out/'contract.json',core.contract())
cmd=[sys.executable,str(snapshot/'run_nli_v3_4_development.py'),'--manifest',str(root/'local_runs/nli_v3_4_20261012/development/manifest.json'),'--output',str(out),'--round','2','--workers','2','--design-python',str(root/'.venv-nli-design/bin/python')]
with (out/'driver.stdout.log').open('a') as log:
 process=subprocess.Popen(cmd,cwd=snapshot,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,env=os.environ.copy())
write_json(out/'driver.json',{'pid':process.pid,'command':cmd,'cwd':str(snapshot),'stage':'development','round':2,'immutable_code_snapshot':True,'local_only':True,'production_allowed':False})
print(json.dumps({'driver_pid':process.pid,'output':str(out),'prompt_contract_unchanged':True,'remote_push':False}))
