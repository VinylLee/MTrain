"""Offline human packet from terminal development outputs, with historical references."""
from pathlib import Path
import collections,datetime,json,random,sys
sys.path.insert(0,str(Path('/home/ubuntu/MTrain')))
from nli_v3_4 import core
from nli_v3_4.data import canonical_source,digest,is_source,load_dataset,sha256,write_json,write_jsonl
ROOT=Path('/home/ubuntu/MTrain/local_runs/nli_v3_4_20261014_round3/pilot_round3_engineering_repair')
FROZEN=Path('/home/ubuntu/MTrain/local_runs/nli_v3_4_20261012/development')
OUTPUT=ROOT/'preliminary_human_review_terminal_three'
if OUTPUT.exists():raise FileExistsError(OUTPUT)
manifest=json.loads((FROZEN/'manifest.json').read_text())
status=json.loads((ROOT/'status.json').read_text())
groups=collections.defaultdict(list);provenance={}
for name in ['train','snli','mnlim']:
 assert name in [k.split('/')[1] for k in status['jobs']], 'not terminal'
 paths=[FROZEN/'development_old'/f'{name}.jsonl',ROOT/'v3_4'/f'{name}.jsonl']
 sides=[]
 for path in paths:
  rows,sources=load_dataset(path)
  assert {s['pair_id'] for s in sources}==set(manifest['datasets'][name]['development_pair_ids'])
  byid={s['pair_id']:s for s in sources};follow={};ordinal=collections.Counter()
  for row in rows:
   if not is_source(row):
    base=(row['pair_id'],row['mr_id']);follow[(*base,ordinal[base])]=row;ordinal[base]+=1
  sides.append((follow,byid))
 assert [canonical_source(s) for s in sides[0][1].values()]==[canonical_source(s) for s in sides[1][1].values()]
 report=json.loads(paths[1].with_suffix('.report.json').read_text())
 assert report['contract_sha256']==core.fingerprint() and report['generation_complete'] is False
 provenance[name]={'v3_3_path':str(paths[0]),'v3_4_path':str(paths[1]),'v3_3_sha256':sha256(paths[0]),'v3_4_sha256':sha256(paths[1]),'new_generation_complete':False,'baseline_kind':'historical_v3_3_on_frozen_development_sources'}
 for key,new in sides[1][0].items():
  pair_id,operation,ordinal=key
  groups[operation].append((name,sides[1][1][pair_id],sides[0][0].get(key),new,ordinal))
rng=random.Random(42);label_rows=[];operation_rows=[];private=[];units=[]
for operation in core.OPERATION_SPECS:
 buckets=collections.defaultdict(list)
 for row in sorted(groups[operation],key=lambda x:(x[0],x[1]['pair_id'],x[4])):buckets[row[0]].append(row)
 for bucket in buckets.values():rng.shuffle(bucket)
 selected=[]
 while len(selected)<20 and any(buckets.values()):
  for name in ['train','snli','mnlim']:
   if buckets[name] and len(selected)<20:selected.append(buckets[name].pop())
 for name,source,old,new,ordinal in selected:
  pair_key=digest([name,source['pair_id'],operation,ordinal]);units.append(pair_key)
  for version,row in [('v3.3',old),('v3.4',new)]:
   if row is None:continue
   review_id=digest(['preliminary_terminal_three',pair_key,version,42])[:20]
   label_rows.append({'review_id':review_id,'premise':row['premise'],'hypothesis':row['hypothesis']})
   operation_rows.append({'review_id':review_id,'source_hypothesis':source['hypothesis'],'hypothesis':row['hypothesis'],'operation':operation,'operation_definition':core.OPERATION_SPECS[operation]['instruction'],'component_mrs':row.get('component_mrs')})
   private.append({'review_id':review_id,'pair_key':pair_key,'dataset':name,'pair_id':source['pair_id'],'version':version,'operation':operation,'expected_label':row['label'],'is_inv':row['mr_type']=='inv','paired':old is not None})
rng.shuffle(label_rows);rng.shuffle(operation_rows)
write_jsonl(OUTPUT/'label_grammar_blind.jsonl',label_rows)
write_jsonl(OUTPUT/'operation_blind.jsonl',operation_rows)
write_jsonl(OUTPUT/'private_key.jsonl',private)
write_json(OUTPUT/'answers.template.json',{'reviewer':'','human_attestation':False,'answers':[{'review_id':r['review_id'],'label':None,'grammatical':None,'operation_valid':None,'source_equivalent':None} for r in label_rows]})
packet={'stage':'preliminary_development_historical_reference','contract_sha256':core.fingerprint(),'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'frozen_manifest_sha256':sha256(FROZEN/'manifest.json'),'datasets':provenance,'pairs':len(units),'review_rows':len(private),'per_mr_target':20,'available_new_review_units_per_mr':{op:len(groups[op]) for op in core.OPERATION_SPECS},'selected_new_review_units_per_mr':dict(collections.Counter(r['operation'] for r in private if r['version']=='v3.4')),'paired_units':sum(r['version']=='v3.4' and r['paired'] for r in private),'new_only_units':sum(r['version']=='v3.4' and not r['paired'] for r in private),'private_key_sha256':sha256(OUTPUT/'private_key.jsonl'),'label_grammar_sha256':sha256(OUTPUT/'label_grammar_blind.jsonl'),'operation_sha256':sha256(OUTPUT/'operation_blind.jsonl'),'model_calls':0,'model_scores_used_in_sampling':False,'freeze_eligible':False,'quality_passed':False,'human_review_complete':False}
write_json(OUTPUT/'manifest.json',packet)
(OUTPUT/'README_zh.md').write_text('''# 初步人工盲审材料\n\n这份材料取自本轮已结束的训练、SNLI与MNLI matched开发输出，共三来源，每来源120个冻结来源。生成均未达到180条目标。MNLI mismatched与SICK不在本材料中。\n\n每MR随机抽取最多20个新输出单元，稀有类型全部纳入，不使用任何模型分数决定抽样。能匹配来源、MR与序号的历史v3.3行作为盲审参考；缺少匹配旧行的新样本照常纳入，不能因旧版本生成失败而遗漏新错误。历史数据不是本次重放对照臂，不能以此材料声称纯提示词效果、正式质量通过或完整实验通过。\n\n先阅读 label_grammar_blind.jsonl，独立判断NLI标签和语法；再阅读 operation_blind.jsonl，判断操作及INV双向等价性。不要查看 private_key.jsonl 或模型诊断。标签为0=entailment、1=neutral、2=contradiction；其余字段填写布尔值，非INV的source_equivalent可留null。把答案填入 answers.template.json 的副本，由真实审核人填写 reviewer 并在全部完成后设置 human_attestation=true。自动模型意见不能作为人工回答。\n\n当前未覆盖MR、稀有MR数量和缺少配对旧行的数量在manifest中公开。本材料stage明确为初步历史参考，freeze入口不接受其作为最终质量证据。后续正式盲审仍需覆盖最终数据及约定对照。\n''')
for p in provenance.values():
 for version in ['v3_3','v3_4']:assert sha256(p[f'{version}_path'])==p[f'{version}_sha256']
assert len({r['review_id'] for r in private})==len(private)
assert set(r['review_id'] for r in label_rows)==set(r['review_id'] for r in operation_rows)
print(json.dumps({k:packet[k] for k in ['pairs','review_rows','paired_units','new_only_units','selected_new_review_units_per_mr','model_scores_used_in_sampling','freeze_eligible']},ensure_ascii=False));print('output',OUTPUT)
