"""Replay every recorded selection in the original immutable round-3 scheduler."""
from collections import Counter
import json
from pathlib import Path
import sys

ROOT = Path('/home/ubuntu/MTrain/local_runs/nli_v3_4_20261014_round3/pilot_round3')
sys.path.insert(0, str(ROOT/'code_snapshot'))
from nli_v3_4 import core
from nli_v3_4.data import digest, source_uid
from nli_v3_4.workflow import source_rows, scheduling_queues

MANIFEST = Path('/home/ubuntu/MTrain/local_runs/nli_v3_4_20261012/development/manifest.json')


def replay(dataset):
    path = ROOT/'v3_4'/f'{dataset}.jsonl'
    meta = json.loads(path.with_suffix('.run.json').read_text())
    assert meta['version'] == 'v3.4' and meta['stage'] == 'development'
    assert meta['contract_sha256'] == core.fingerprint()
    _,_,sources = source_rows(MANIFEST, dataset, 'development')
    assert digest(sources) == meta['source_sha256']
    payload = path.with_suffix('.generation_log.jsonl').read_bytes()
    lines = payload.splitlines()
    if payload and not payload.endswith(b'\n'):
        lines = lines[:-1]
    logs = [json.loads(l) for l in lines if l.strip()]
    assert not any(e.get('pending_continuation') for e in logs)
    counts, inv_counts = Counter(), Counter()
    attempts_by_mr, accepted_by_mr, attempts_by_source = Counter(), Counter(), Counter()
    wanted = {int(k):v for k,v in meta['label_quotas'].items()}
    inv_minimum = {int(k):v for k,v in meta['minimum_invariant_counts'].items()}
    cursor = 0
    for refill in range(meta['max_refill_rounds']):
        queues = scheduling_queues(sources, meta['seed'], refill, core)
        while True:
            def permitted(label):
                return [op for op,q in queues[label].items() if q and
                    (core.OPERATION_SPECS[op]['family']=='inv' or
                     counts[label]-inv_counts[label] < wanted[label]-inv_minimum[label])]
            labels = [l for l in range(3) if counts[l] < wanted[l] and permitted(l)]
            if not labels:
                break
            label = min(labels, key=lambda l:(counts[l]/max(1,wanted[l]),l))
            operations = permitted(label)
            invariant = [op for op in operations if core.OPERATION_SPECS[op]['family']=='inv']
            if inv_counts[label] < inv_minimum[label] and invariant:
                operations = invariant
            op = min(operations, key=lambda op:(attempts_by_mr[(label,op)],accepted_by_mr[(label,op)],op))
            source = min(queues[label][op],key=lambda s:attempts_by_source[s['pair_id']])
            queues[label][op].remove(source)
            expected = {'request_id':digest([source_uid(source),op,refill,meta['seed'],meta['version']]),
                        'pair_id':source['pair_id'],'source_uid':source_uid(source),'operation':op,
                        'refill_round':refill,'target_label':label}
            if cursor == len(logs):
                return {'dataset':dataset,'validated_requests':cursor,'next_request':expected,
                        'model_calls':0,'journal_snapshot_sha256':__import__('hashlib').sha256(payload).hexdigest()}
            entry = logs[cursor]
            assert all(entry.get(k)==v for k,v in expected.items()), (dataset,cursor,expected,entry)
            if entry.get('row'):
                row = entry['row']
                assert row['label']==label and row['mr_id']==op
                counts[label] += 1
                accepted_by_mr[(label,op)] += 1
                if core.OPERATION_SPECS[op]['family']=='inv':
                    inv_counts[label] += 1
            attempts_by_mr[(label,op)] += 1
            attempts_by_source[source['pair_id']] += 1
            cursor += 1
    assert cursor == len(logs)
    return {'dataset':dataset,'validated_requests':cursor,'next_request':None,'model_calls':0,
            'journal_snapshot_sha256':__import__('hashlib').sha256(payload).hexdigest()}


if __name__=='__main__':
    print(json.dumps({d:replay(d) for d in ('train','snli','mnlim','mnlimm')}))
