# 可选：原始来源标签分歧复核

原盲审中8条新INV记录被同时判断为等价、但人工标签不同于继承gold，对应8个原始来源。这里仅展示原始premise/hypothesis，用于独立判断源标签。

先阅读source_pairs_blind.jsonl并填写answers.template.json副本；label为0=entailment、1=neutral、2=contradiction，可用note记录歧义。请先独立判断，再查看private_key.jsonl。完成后填写真实审核人标识并声明human_attestation。

这是定位源标注或两阶段判断分歧的可选诊断。结果与原审核分别保存，不会覆盖原答案、修改源gold、筛选增强行或改变已经得到的本轮质量不通过结论。无需为了当前结论立即完成此项；可在下一轮质量修复设计时使用。
