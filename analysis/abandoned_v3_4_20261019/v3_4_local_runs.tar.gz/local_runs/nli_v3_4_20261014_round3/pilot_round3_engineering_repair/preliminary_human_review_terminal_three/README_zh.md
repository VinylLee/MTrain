# 初步人工盲审材料

这份材料取自本轮已结束的训练、SNLI与MNLI matched开发输出，共三来源，每来源120个冻结来源。生成均未达到180条目标。MNLI mismatched与SICK不在本材料中。

每MR随机抽取最多20个新输出单元，稀有类型全部纳入，不使用任何模型分数决定抽样。能匹配来源、MR与序号的历史v3.3行作为盲审参考；缺少匹配旧行的新样本照常纳入，不能因旧版本生成失败而遗漏新错误。历史数据不是本次重放对照臂，不能以此材料声称纯提示词效果、正式质量通过或完整实验通过。

先阅读 label_grammar_blind.jsonl，独立判断NLI标签和语法；再阅读 operation_blind.jsonl，判断操作及INV双向等价性。不要查看 private_key.jsonl 或模型诊断。标签为0=entailment、1=neutral、2=contradiction；其余字段填写布尔值，非INV的source_equivalent可留null。把答案填入 answers.template.json 的副本，由真实审核人填写 reviewer 并在全部完成后设置 human_attestation=true。自动模型意见不能作为人工回答。

当前未覆盖MR、稀有MR数量和缺少配对旧行的数量在manifest中公开。本材料stage明确为初步历史参考，freeze入口不接受其作为最终质量证据。后续正式盲审仍需覆盖最终数据及约定对照。
