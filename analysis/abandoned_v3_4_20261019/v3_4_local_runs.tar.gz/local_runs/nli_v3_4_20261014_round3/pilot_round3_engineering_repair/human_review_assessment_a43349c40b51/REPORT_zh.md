# 人工复核记录已归档：质量判定不通过

审核人字段已补齐，human_attestation=true；188条答案通过完整性、ID及字段检查，盲审数据哈希与原记录相符。
已运行项目正式assess评估器并保存formal_assessment.json；质量数值与先前初步计算一致。
本记录范围仍为preliminary_development_historical_reference，即开发阶段历史参考盲审。

| 指标 | 所审v3.4样本 | 既定门槛 |
|---|---:|---:|
| 标签正确 | 73.19% | ≥95% |
| 语法合格 | 62.32% | ≥95% |
| MR操作成立 | 48.55% | ≥95% |
| INV双向等价 | 51.67% | ≥95% |

四项未达到门槛，quality_passed=false。审核人补齐解决了归档缺项；现有质量结果仍不支持冻结提示词或扩大生成。
INV历史参考仅1个配对单元，不能凭其bootstrap区间声称总体INV不劣于旧版。MR／数据集抽样配额也不同于681条总体比例，以上为所审样本统计。
当前未启动追加预算、未修改生成数据或原答案。建议优先修复已定位的拼接语法、voice资格、同义及复合等价问题，后续用独立小样本复核。

答案快照：answers.input.snapshot.json；正式评分：formal_assessment.json；归档校验：archive_validation.json。
