# 第三轮训练／SNLI终态缺口诊断

仅使用已结束的两个生成任务；未调用模型、未修改生成数据，未增加生成或评审预算。
这份报告记录候选与预算状态；候选检查、Gemma评审和NLI模型诊断均不能代替人工质量真值。

| 来源 | 已接受／目标 | E/N/C | E/N/C 缺口 | INV E/N/C 缺口 |
|---|---:|---|---|---|
| train | 104/180 | 24/44/36 | 36/16/24 | 36/16/24 |
| snli | 123/180 | 34/52/37 | 26/8/23 | 26/8/23 |

训练与SNLI的常规生成调度均已结束，数量与INV配额未满足。训练剩余3个续评请求属于已满额的非INV分配，不能补足缺少的INV；SNLI没有待续请求。
继续执行同一恢复命令不能重新获得已消耗的生成／评审槽位。不能以缩小目标、增加非INV行或改变已有标签弥补缺口。

逐原子尝试诊断（复合阶段不参与此计数，避免使用错误的中间来源）：

## train
- atomic_attempts: 1773
- saved_raw_has_deterministically_valid_candidate: 597
- valid_candidate_has_saved_judgment: 591
- complete_payload_without_deterministically_valid_candidate: 1174
- valid_candidate_no_saved_judgment: 6
- saved_raw_parse_error_ValueError: 2

这些是对已保存响应的离线解析计数，不代表真实语义错误率。已完成JSON格式兼容后，仍可能因空数组弃权、词索引／保护词规则或语义评审未通过而缺少数据。

## snli
- atomic_attempts: 1787
- saved_raw_has_deterministically_valid_candidate: 536
- valid_candidate_has_saved_judgment: 525
- complete_payload_without_deterministically_valid_candidate: 1250
- valid_candidate_no_saved_judgment: 11
- saved_raw_parse_error_ValueError: 1

这些是对已保存响应的离线解析计数，不代表真实语义错误率。已完成JSON格式兼容后，仍可能因空数组弃权、词索引／保护词规则或语义评审未通过而缺少数据。

## 尚待完成
其他三个来源仍需跑完固定预算并由驱动器输出四集临时probe；所有来源完整性、真实人工盲审与完整正式数据结果尚缺。
第三轮是原计划允许的最后一轮语义提示词。若所有固定预算完成后仍有缺口，必须明确报告计划未完成；任何增加语义开发轮次、调用预算或改变MR定义的继续实验都应使用新授权和独立实验身份。
