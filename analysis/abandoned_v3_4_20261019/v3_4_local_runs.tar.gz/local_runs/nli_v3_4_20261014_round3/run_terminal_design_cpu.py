"""Read-only design diagnostics for completed development files; never production."""
from pathlib import Path
import datetime,json,os,subprocess,sys
sys.path.insert(0,'/home/ubuntu/MTrain')
from nli_v3_4.data import sha256,write_json
ROOT=Path('/home/ubuntu/MTrain/local_runs/nli_v3_4_20261014_round3/pilot_round3_engineering_repair')
SNAPSHOT=ROOT/'code_snapshot'
PYTHON='/home/ubuntu/MTrain/.venv-nli-design/bin/python'
MANIFEST=Path('/home/ubuntu/MTrain/local_runs/nli_v3_4_20261012/development/manifest.json')
STATE=ROOT/'early_design_cpu_status.json'
state={'stage':'development','round':3,'state':'running','pid':os.getpid(),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'device':'cpu','concurrency':1,'used_to_filter_data':False,'production_dependency':False,'generation_model_calls':0,'jobs':{}}
write_json(STATE,state)
try:
 for name in ['train','snli','mnlim','mnlimm']:
  status=json.load(open(ROOT/'status.json'));assert status['jobs'][f'v3_4/{name}']['exit_code']==0
  path=ROOT/'v3_4'/f'{name}.jsonl';before=sha256(path);output=ROOT/'design_diagnostics'/name
  assert not (output/'report.json').exists(),'another diagnostic already exists'
  cmd=[PYTHON,str(SNAPSHOT/'analysis/design_nli_quality.py'),'--manifest',str(MANIFEST),'--dataset',name,'--generated',str(path),'--output',str(output),'--device','cpu']
  with (ROOT/f'early_design_{name}.stdout.log').open('x') as log:
   child=subprocess.Popen(cmd,cwd=SNAPSHOT,stdout=log,stderr=subprocess.STDOUT)
   state['jobs'][name]={'state':'running','pid':child.pid,'command':cmd,'input_sha256':before};write_json(STATE,state)
   code=child.wait()
  assert sha256(path)==before,'generated input changed during read-only diagnostic'
  if code:raise RuntimeError(f'{name} diagnostic exit {code}')
  report=json.load(open(output/'report.json'))
  state['jobs'][name].update(state='completed',exit_code=code,report=str(output/'report.json'),input_unchanged=True)
  write_json(STATE,state)
 state.update(state='completed',finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());write_json(STATE,state)
except BaseException as exc:
 state.update(state='failed',error=f'{type(exc).__name__}: {exc}');write_json(STATE,state);raise
