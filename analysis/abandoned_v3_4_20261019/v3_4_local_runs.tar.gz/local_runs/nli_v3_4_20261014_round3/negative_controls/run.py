from pathlib import Path
from openai import OpenAI
from nli_v3_4 import core
from nli_v3_4.data import read_jsonl,write_json
root=Path('local_runs/nli_v3_4_20261014_round3/negative_controls')
rows=read_jsonl('local_runs/nli_v3_4_20261012/development/development_sources/train.jsonl')
cases=[('a figure is walking','a person is moving'),('A boat floats.','A vessel drifts.'),('The worker is hitting the nail','The worker is hammering the nail')]
client=OpenAI(api_key='local',base_url='http://127.0.0.1:1234/v1',timeout=120,max_retries=0);results=[]
for original,candidate in cases:
 source=next(r for r in rows if r['hypothesis'].strip().rstrip('.').lower()==original.strip().rstrip('.').lower())
 trace={};verdicts=core.judge_current(client,source,'synonym_replacement',[candidate],trace)
 chosen=core.choose_current([candidate],verdicts,source,'synonym_replacement')
 results.append({'source':source,'candidate':candidate,'expected_equivalence':False,'chosen':bool(chosen),'trace':trace,'judgments':verdicts})
 write_json(root/'results.json',{'stage':'development_negative_controls_only','contract_sha256':core.fingerprint(),'results':results})
 print(original, bool(chosen),flush=True)
