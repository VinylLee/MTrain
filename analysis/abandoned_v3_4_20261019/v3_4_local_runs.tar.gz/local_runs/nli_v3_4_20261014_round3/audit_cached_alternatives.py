from pathlib import Path
import json,sys
sys.path.insert(0,'/home/ubuntu/MTrain')
from nli_v3_4 import core
from nli_v3_4.data import load_dataset,normalize,sha256,write_json
from nli_v3_4.protocol import replay_atomic
ROOT=Path('/home/ubuntu/MTrain/local_runs/nli_v3_4_20261014_round3/pilot_round3_engineering_repair')
result={'stage':'offline_atomic_duplicate_recovery_audit','model_calls':0,'accepted_new_rows':0,'composite_intermediate_alternatives_excluded':True,'datasets':{}}
for name in ['train','snli','mnlim','mnlimm','sick']:
 p=ROOT/'v3_4'/f'{name}.jsonl';rows,src=load_dataset(p);byid={s['pair_id']:s for s in src};known={(normalize(r['premise']),normalize(r['hypothesis'])) for r in rows};j=p.with_name(f'{name}.generation_log.jsonl');saved_unique=[];unjudged_unique=[];seen=set();all_nojudgment=0;duplicate_selected=0
 for line in j.read_text().splitlines():
  r=json.loads(line);op=r['operation'];trace=r.get('trace',{});source=byid[r['pair_id']]
  if r['row'] is not None or trace.get('status')!='accepted' or op in core.COMPOSITE_STAGE_PLANS:continue
  duplicate_selected+=1
  for a in trace.get('attempts',[]):
   if not a.get('raw_generation'):continue
   try:candidates=core.parse_candidates(a['raw_generation'],source,op)
   except ValueError:continue
   for h in candidates:
    key=(normalize(source['premise']),normalize(h))
    if a.get('raw_judgment') is None:
     all_nojudgment+=1
     if any(e['role']!='generation' for e in a.get('model_call_events',[])) or key in known or key in seen:continue
     unjudged_unique.append({'request_id':r['request_id'],'pair_id':r['pair_id'],'operation':op,'target_label':r['target_label'],'round':a['round'],'candidate':h,'saved_generation_only':True});seen.add(key)
    elif key not in known and key not in seen:
     try:text,_=replay_atomic(source,op,trace,core.parse_candidates,h,core.OPERATION_SPECS[op]['family']=='inv')
     except ValueError:continue
     if text==h:saved_unique.append({'request_id':r['request_id'],'pair_id':r['pair_id'],'operation':op,'target_label':r['target_label'],'candidate':h});seen.add(key)
 result['datasets'][name]={'output_sha256':sha256(p),'journal_sha256':sha256(j),'accepted_trace_without_row':duplicate_selected,'candidate_count_without_judgment_in_these_traces':all_nojudgment,'unique_candidates_with_approved_cached_verdict':saved_unique,'unique_candidates_with_unused_judgment_slot':unjudged_unique}
write_json(ROOT/'terminal_all_five_cached_alternatives.json',result)
print({name:{'approved_cached_unique_candidates':len(d['unique_candidates_with_approved_cached_verdict']),'unique_candidates_with_unused_judgment_slot':len(d['unique_candidates_with_unused_judgment_slot'])} for name,d in result['datasets'].items()})
