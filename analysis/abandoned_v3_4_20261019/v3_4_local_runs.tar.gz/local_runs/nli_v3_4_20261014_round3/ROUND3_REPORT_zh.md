# 第三轮：本地降低 NLI 捷径实验

目标仍为 active，完整新训练文件→四个完整新测试文件的固定 hypothesis-only TF-IDF＋逻辑回归增强行 accuracy 均≤60%，且真实人工质量门槛通过。当前没有全量验收或人工通过的证据。

第二轮实际生成829/900条，固定600来源均保留。临时探针用293行试验训练文件拟合，四集增强行分别170/149/157/180条，accuracy分别68.82%、59.73%、67.52%、57.78%。E配额有缺口，不能将两个点估计通过写成总体通过，也不能代替完整实际文件确认。

第三轮已从独立代码快照启动，最多2个API工作进程，仍使用原冻结600来源及种子42。更新的INV生成仅读取原hypothesis；同义词输出明确索引编辑计划，代码保留其他文字，标签由合法INV继承原Gold。评审按两组明确的NLI比较判断，再检查操作；一般英语的合法voice不再受视觉动词名单限制。数字、名字、极性、语法和时态／aspect继续检查。

所有来源采用同一固定分布：E全部INV，N/C各至少80%合法INV，其余配额保留原neutral／flip操作。此项是数据分布调整，旧表达对照不采用该分配，不能把全部差异归因于纯提示词。合法候选不足只能partial，不跨关系族补足，不增加已约定候选／重试预算。

134项测试通过；第三轮定向接口接受两条合法N/C INV，拒绝walking→moving、boat floats→vessel drifts、hitting→hammering等三个变宽反例。children/kids例未获Gemma双向批准，仍拒绝，不靠外部模型强行接受。这些是小规模设计检查，不是质量真值或人审。

DeBERTa和RoBERTa只用于开发诊断；第二轮五来源分别有59/173、57/170、42/149、36/157、67/180行触发模型诊断标记，标记不是错误率。生成没有依据这些分数过滤、选择或改标签，第三轮正式生成代码不导入或调用两模型。

代词先行词范围的澄清仍待用户答复，当前严格解释在600来源中无合法PN来源，不声明该MR质量证据齐全。此项和真实人工复核尚未解决。所有旧输入及先前日志保留；因旧中断方式未取消排队任务而残留的驱动，已彻底结束并核实，修复已通过实际SIGINT／SIGTERM子进程测试。没有执行远程push。

进程与逐请求状态：pilot_round3/progress_live.json；配置及代码身份：pilot_round3/code_snapshot_manifest.json。未满足完整性、四集主指标和人工质量全部要求，不将goal标记complete。

最新检查点：143行试验训练文件（120原始＋23增强）→26条SNLI增强，固定探针accuracy38.46%。样本很少，只有一个测试来源，不符合全量目标验收。两NLI模型诊断23条中标记5条，只是设计信号。

补充格式兼容修复已通过136项测试：完整单候选对象与数组同等检查，完整JSON值后的冗余关闭符可忽略；不会猜缺失内容、篡改词索引或跳过语义判断。实际多起错误为嵌套括号顺序错误，当前离线检查未恢复可接受候选。运行快照未修改，修复待当前执行终止后再按独立身份验证。

更新：已准备development-only JSON Schema及后台语法探针，索引与原词必须同时匹配；离线回归总计138项通过。LM Studio官方接口文档支持response_format JSON Schema（https://lmstudio.ai/docs/developer/openai-compat/structured-output），但当前Gemma后端能力尚未实测。因两个生成工作进程都仍在执行，探针按并发约束退出，没有调用模型。此代码未集成到运行快照或正式增强方法中。

现场进度（UTC 2026-10-14T06:36:20Z）：{"train": {"requests": 335, "followups": 53, "labels": {"0": 18, "1": 18, "2": 17}}, "snli": {"requests": 335, "followups": 53, "labels": {"0": 17, "1": 18, "2": 18}}}；此检查为已确认活跃进程的等待，目标未完成。

第二检查点（2026-10-14T09:19:12.289026+00:00）：216行训练快照→107条SNLI增强，固定probe accuracy45.79%（95% CI 36.36%–55.35%），并非全量验收；训练／SNLI两模型标记分别21/96、45/107。详情见pilot_round3/diagnostic_checkpoints/checkpoint02/REPORT_zh.md。原始五文件和活跃代码快照哈希全部吻合。活跃PID2160692仍在执行；当前计数：{"train": {"requests": 1025, "followups": 98, "labels": {"0": 23, "1": 39, "2": 36}}, "snli": {"requests": 1030, "followups": 109, "labels": {"0": 30, "1": 43, "2": 36}}}。

恢复工程修复（2026-10-14T09:38:19.943941+00:00，本地35d02f1）：原有逐请求日志不能保存请求中途的API响应。新版本在每个调用发送前与返回后分别持久化；已存响应原样复用，结果未知的调用消耗原槽位且不重新发送。候选、标签、MR规则和三轮提示词预算均未改变。143项测试通过，包括真实SIGKILL和生成第二轮剩余预算恢复。代码／原始五输入哈希继续吻合；活跃第三轮快照未应用新修复，不能篡改其身份直接续跑新代码。当前活跃PID2160692，计数{"train": {"requests": 1110, "followups": 100, "labels": {"0": 23, "1": 41, "2": 36}}, "snli": {"requests": 1115, "followups": 114, "labels": {"0": 30, "1": 48, "2": 36}}}。

JSON末尾括号兼容及未用评审恢复（2026-10-14T10:43:29.852438+00:00，本地e77e0b8）：391次保存格式错误中387次可在括号种类／数量完全不变时，仅按前缀的唯一已开层次重排关闭符。现有词索引与编辑检查仍拒绝其他候选，114次产生待评审候选，不是接受行。离线整请求检查确认训练58个、SNLI42个请求存在原预算中的未使用评审槽位（分别覆盖目标E/N/C 24/17/17、15/17/10）；未调用模型或生成新候选，接受新行数0。已经调用的失败／未知评审和缺少调用来源证明的槽位不重试。155项测试通过。当前活跃快照与五原始输入保持原哈希；当前计数{"train": {"requests": 1424, "followups": 101, "labels": {"0": 23, "1": 42, "2": 36}}, "snli": {"requests": 1422, "followups": 119, "labels": {"0": 34, "1": 49, "2": 36}}, "mnlim": {"state": "pending", "followups": 0}, "mnlimm": {"state": "pending", "followups": 0}, "sick": {"state": "pending", "followups": 0}}。恢复须保留原始批次，再建立显式工程修复身份，不能修改原元数据绕过身份保护，也不是第四轮提示词。

训练／SNLI固定请求预算结束（2026-10-14T11:07:17.149253+00:00）：原生成PID2160703/2160704均已不存在，输出／日志哈希核对通过。训练1495请求得到102/180增强（E/N/C缺口37/17/24），SNLI1493请求得到120/180增强（缺口26/10/24）。222行试验训练→120条SNLI增强的固定probe accuracy43.33%（95% CI 33.89%–52.78%，多数类41.67%），不是全量验收。两开发NLI模型分别标记训练24/102、SNLI50/120，只作设计诊断，不据此筛选。详情见pilot_round3/diagnostic_checkpoints/terminal_train_snli/REPORT_zh.md。MNLI matched／mismatched PID2239230/2239426已实际启动；SICK待执行。所有原始输入、活跃快照哈希仍一致。

原始开发句对诊断（2026-10-14T11:44:36.062820+00:00）：冻结600来源均由两NLI模型评分，仅作设计诊断、未过滤／改标签。SNLI原始句对的模型Gold一致率83.33%/84.17%，SICK为75.83%/72.50%，故增强50/120等诊断标记不可直接当错误率。SNLI合法INV96行中，DeBERTa原始与增强均低置信22行、新增低置信3行；RoBERTa分别28与6行（阈值0.8）。仍不证明标签、语法或INV质量；真实人审缺失。详情见development_source_baseline/REPORT_zh.md。生成PID2239230/2239426仍活跃，现场计数{"train": {"requests": 1495, "followups": 102, "labels": {"0": 23, "1": 43, "2": 36}}, "snli": {"requests": 1493, "followups": 120, "labels": {"0": 34, "1": 50, "2": 36}}, "mnlim": {"requests": 260, "followups": 44, "labels": {"0": 15, "1": 15, "2": 14}}, "mnlimm": {"requests": 267, "followups": 29, "labels": {"0": 10, "1": 10, "2": 9}}, "sick": {"state": "pending", "followups": 0}}。

工程修复迁移并已续跑（2026-10-14T13:32:54.898371+00:00）：旧PID2160692/2239230/2239426已正常中断并逐一确认终止。原调度完整逐请求回放相符，据停止后的稳定日志定位MNLI两个可能在途请求，保守消耗整请求原预算（实际调用次数未知），没有伪造输出或语义复核。旧文件20项哈希均保持；SICK此前排队未启动，仅准备120原始行，0模型调用。实际Gemma JSON Schema语法探针成功，接受行0；新工程版本为69a85bc，157项测试通过。迁移原有387条增强全部保留，待原预算续作168请求，迁移推理调用0。独立快照pilot_round3_engineering_repair、监督PID2274527已实际运行训练／SNLI恢复，每次新API调用独立持久化。提示词仍第三轮、600来源与语义契约e26b不变；格式约束是额外显式解码干预，结果不能仅归因于提示词。新root不导入两外部NLI模型参与样本选择、过滤、改标签，所有NNI教师分数仍只作开发设计诊断。现场计数{"train": {"requests": 1495, "followups": 104, "labels": {"0": 24, "1": 44, "2": 36}, "pending_continuations": 39, "unknown_budget_reservations": 0}, "snli": {"requests": 1493, "followups": 122, "labels": {"0": 34, "1": 51, "2": 37}, "pending_continuations": 18, "unknown_budget_reservations": 0}, "mnlim": {"requests": 570, "followups": 91, "labels": {"0": 23, "1": 32, "2": 36}, "pending_continuations": 29, "unknown_budget_reservations": 1}, "mnlimm": {"requests": 595, "followups": 74, "labels": {"0": 23, "1": 26, "2": 25}, "pending_continuations": 25, "unknown_budget_reservations": 1}, "sick": {"requests": 0, "followups": 0, "labels": {}, "pending_continuations": 0, "unknown_budget_reservations": 0}}；完整目标和人审未验证，无远程push。

修复快照恢复检查（2026-10-14T13:40:45.987713+00:00）：训练/SNLI原未用评审处理后达到104/180、123/180增强，均仍partial；训练剩余3个pending标记对应已满的composite_flip/composite_neutral非INV分配，不能用来覆盖INV缺口。MNLI matched/mismatched PID2275681/2275894已在新快照继续，现场计数{"train": {"requests": 1495, "followups": 104, "labels": {"0": 24, "1": 44, "2": 36}, "pending_continuations": 3, "unknown_budget_reservations": 0}, "snli": {"requests": 1493, "followups": 123, "labels": {"0": 34, "1": 52, "2": 37}, "pending_continuations": 0, "unknown_budget_reservations": 0}, "mnlim": {"requests": 600, "followups": 104, "labels": {"0": 28, "1": 38, "2": 38}, "pending_continuations": 3, "unknown_budget_reservations": 1}, "mnlimm": {"requests": 617, "followups": 79, "labels": {"0": 23, "1": 28, "2": 28}, "pending_continuations": 2, "unknown_budget_reservations": 1}, "sick": {"requests": 0, "followups": 0, "labels": {}, "pending_continuations": 0, "unknown_budget_reservations": 0}}。只读观察器原PID2274528因启动导入路径错误结束，补齐PYTHONPATH与driver.json后新PID2276603已实际存活并写入progress_live；代码快照与五原始输入哈希检查均通过，旧20文件哈希仍不变。未满足人审及全量目标，不freeze、不标记complete。
