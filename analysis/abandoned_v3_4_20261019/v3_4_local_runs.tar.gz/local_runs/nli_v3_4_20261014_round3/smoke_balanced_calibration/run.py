import json
from pathlib import Path
from openai import OpenAI
from nli_v3_4 import core
from nli_v3_4.data import read_jsonl,write_json
root=Path('local_runs/nli_v3_4_20261014_round3/smoke_balanced_calibration')
base=Path('local_runs/nli_v3_4_20261012/development/development_sources')
mnli={r['pair_id']:r for r in read_jsonl(base/'mnlim.jsonl')}
training=read_jsonl(base/'train.jsonl')
child=next(r for r in training if r['label']==0 and ('children' in r['hypothesis'].lower() or 'child' in r['hypothesis'].lower()))
cases=[('mnlim',mnli[766],'synonym_replacement'),('mnlim',mnli[7311],'voice_switch'),('train',child,'synonym_replacement')]
client=OpenAI(api_key='local',base_url='http://127.0.0.1:1234/v1',timeout=120,max_retries=0)
results=[]
for d,source,op in cases:
 text,trace=core.generate_one(client,source,op)
 result={'dataset':d,'source':source,'operation':op,'accepted':text is not None,'text':text,'trace':trace}
 results.append(result);write_json(root/'results.json',{'stage':'development_interface_smoke','not_formal_trial':True,
  'contract_sha256':core.fingerprint(),'results':results})
 print(d,source['pair_id'],op,text,flush=True)
