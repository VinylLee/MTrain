"""One-off frozen-development source diagnosis; no augmentation selection API."""
from collections import Counter
from pathlib import Path
import json
import sys

sys.path.insert(0, '/home/ubuntu/MTrain')
import torch
from transformers import AutoTokenizer, AutoModelForSequenceClassification
from analysis.design_nli_quality import MODELS, score_tasks
from nli_v3_4.data import sha256, source_uid, write_json, write_jsonl, canonical_source, load_dataset

BASE = Path('/home/ubuntu/MTrain/local_runs/nli_v3_4_20261014_round3')
MANIFEST = Path('/home/ubuntu/MTrain/local_runs/nli_v3_4_20261012/development/manifest.json')
OUTPUT = BASE / 'development_source_baseline'
if OUTPUT.exists():
    raise FileExistsError(OUTPUT)
manifest_hash = sha256(MANIFEST)
assert manifest_hash == 'd1447cd821f8a0417e82a36b39e8fdc0dc62585341162a968e0eb98f8d669255'
labels = ('entailment', 'neutral', 'contradiction')
records, frozen_inputs = [], {}
manifest = json.loads(MANIFEST.read_text())
for dataset in ('train', 'snli', 'mnlim', 'mnlimm', 'sick'):
    info = manifest['datasets'][dataset]
    assert sha256(info['input']) == info['sha256']
    _, original_sources = load_dataset(info['input'])
    ids = set(info['development_pair_ids'])
    sources = [canonical_source(s) for s in original_sources if s['pair_id'] in ids]
    assert manifest['per_label'] == 40 and manifest['seed'] == 42
    assert len(sources) == 120 and Counter(s['label'] for s in sources) == {0:40, 1:40, 2:40}
    assert {s['pair_id'] for s in sources} == set(info['development_pair_ids'])
    frozen_inputs[info['input']] = info['sha256']
    for source in sources:
        records.append({'dataset':dataset, 'pair_id':source['pair_id'], 'source_uid':source_uid(source),
                        'expected_label':labels[source['label']], 'premise':source['premise'],
                        'hypothesis':source['hypothesis'], 'scores':{}})
assert len(records) == 600
torch.set_num_threads(2)
tasks = [(i, r['premise'], r['hypothesis']) for i,r in enumerate(records)]
cache = Path.home()/'.cache/huggingface/hub'
models = {}
for name,(model_id,revision) in MODELS.items():
    snapshot = cache/('models--'+model_id.replace('/','--'))/'snapshots'/revision
    tokenizer = AutoTokenizer.from_pretrained(snapshot, local_files_only=True)
    model = AutoModelForSequenceClassification.from_pretrained(snapshot, local_files_only=True,
                    use_safetensors=True).to('cpu').eval()
    scores = score_tasks(model, tokenizer, tasks, 'cpu', 8)
    assert len(scores) == 600
    for row,score in zip(records,scores):
        row['scores'][name] = score
    models[name] = {'model_id':model_id,'revision':revision,'device':'cpu',
                    'weights_sha256':sha256(snapshot/'model.safetensors'),
                    'config_sha256':sha256(snapshot/'config.json'),'id2label':model.config.id2label}
    del model
summary = {}
for dataset in ('train','snli','mnlim','mnlimm','sick'):
    rows = [r for r in records if r['dataset'] == dataset]
    summary[dataset] = {}
    for name in MODELS:
        scored = [r for r in rows if r['scores'][name]['status'] == 'scored']
        summary[dataset][name] = {'sources':len(rows),'scored_sources':len(scored),
            'unscored_sources':len(rows)-len(scored),
            'gold_agreement_rate':sum(r['scores'][name]['prediction']==r['expected_label'] for r in scored)/len(scored) if scored else None,
            'low_gold_probability_sources':sum(r['scores'][name]['probabilities'][r['expected_label']] < .8 for r in scored)}
lookup = {(r['dataset'],r['pair_id']):r for r in records}
comparisons, paired = {}, []
for dataset in ('train','snli'):
    diagnostic = BASE/'pilot_round3/design_diagnostics'/dataset
    metadata = json.loads((diagnostic/'report.json').read_text())
    assert metadata['manifest_sha256'] == manifest_hash and not metadata['used_to_filter_data']
    rows = [json.loads(l) for l in (diagnostic/'design_scores.jsonl').read_text().splitlines()]
    counts = {name:Counter() for name in MODELS}
    for row in rows:
        if row['mr_id'] not in {'synonym_replacement','voice_switch','pronoun_substitution','composite_inv'}:
            continue
        source = lookup[(dataset,row['pair_id'])]
        assert source['hypothesis'] == row['source_hypothesis'] and source['premise'] == row['premise']
        assert source['expected_label'] == row['expected_label']
        item = {'dataset':dataset,'pair_id':row['pair_id'],'mr_id':row['mr_id'],
                'source_hypothesis':source['hypothesis'],'followup_hypothesis':row['hypothesis'], 'models':{}}
        for name in MODELS:
            original,follow = source['scores'][name],row['scores'][name]['pair']
            if original['status'] != 'scored' or follow['status'] != 'scored':
                counts[name]['unscored'] += 1
                continue
            gold = source['expected_label']
            p0,p1 = original['probabilities'][gold],follow['probabilities'][gold]
            category = ('both_low' if p0 < .8 and p1 < .8 else 'new_low_after_inv' if p0 >= .8 and p1 < .8
                        else 'low_resolved_after_inv' if p0 < .8 and p1 >= .8 else 'both_high')
            counts[name][category] += 1
            item['models'][name] = {'original_gold_probability':p0,'followup_gold_probability':p1,
                                    'original_prediction':original['prediction'], 'followup_prediction':follow['prediction'],
                                    'category':category,'human_truth':False}
        paired.append(item)
    comparisons[dataset] = {name:dict(c) for name,c in counts.items()}
assert sha256(MANIFEST) == manifest_hash
assert all(sha256(p)==h for p,h in frozen_inputs.items())
write_jsonl(OUTPUT/'source_scores.jsonl',records)
write_jsonl(OUTPUT/'paired_inv_probabilities.jsonl',paired)
report = {'stage':'frozen_development_source_diagnostic_only','manifest_sha256':manifest_hash,
          'source_count':600,'models':models,'source_gold_agreement':summary,'paired_inv_categories':comparisons,
          'source_inputs_unchanged':True,'used_to_filter_data':False,'production_dependency':False,
          'human_review_complete':False,'freeze_eligible':False,'accepted_rows':0}
write_json(OUTPUT/'report.json',report)
print(json.dumps({'source_count':600,'source_gold_agreement':summary,'paired_inv_categories':comparisons,
                  'used_to_filter_data':False,'human_review_complete':False}))
