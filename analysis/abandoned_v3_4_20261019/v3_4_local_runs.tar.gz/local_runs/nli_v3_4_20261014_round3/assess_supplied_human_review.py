"""Evaluate supplied human answers without inventing a missing reviewer identity."""
from pathlib import Path
import collections,datetime,json,sys
import numpy as np
sys.path.insert(0,'/home/ubuntu/MTrain')
from analysis.nli_v3_4_review import assess
from nli_v3_4.data import sha256,write_json,write_jsonl,load_dataset,is_source
ROOT=Path('/home/ubuntu/MTrain/local_runs/nli_v3_4_20261014_round3/pilot_round3_engineering_repair')
PACKET=ROOT/'preliminary_human_review_all_five';ANSWERS=PACKET/'answers.template.done.json'
answer_sha=sha256(ANSWERS);manifest=json.loads((PACKET/'manifest.json').read_text());supplied=json.loads(ANSWERS.read_text());keys=[json.loads(s) for s in (PACKET/'private_key.jsonl').read_text().splitlines() if s];answers={a['review_id']:a for a in supplied['answers']}
assert len(answers)==len(supplied['answers'])==len(keys) and set(answers)=={k['review_id'] for k in keys}
for key,file in [('private_key_sha256','private_key.jsonl'),('label_grammar_sha256','label_grammar_blind.jsonl'),('operation_sha256','operation_blind.jsonl')]:assert sha256(PACKET/file)==manifest[key]
for d in manifest['datasets'].values():
 for v in ['v3_3','v3_4']:assert sha256(d[f'{v}_path'])==d[f'{v}_sha256']
OUT=ROOT/f'human_review_assessment_{answer_sha[:12]}'
if OUT.exists():raise FileExistsError(OUT)
OUT.mkdir()
formal_error=None
try:assess(PACKET,ANSWERS,OUT/'formal_assessment.json')
except ValueError as exc:formal_error=str(exc)
labels={r['review_id']:r for r in map(json.loads,(PACKET/'label_grammar_blind.jsonl').read_text().splitlines())};ops={r['review_id']:r for r in map(json.loads,(PACKET/'operation_blind.jsonl').read_text().splitlines())}
all_values=collections.defaultdict(lambda:collections.defaultdict(list));paired=collections.defaultdict(lambda:collections.defaultdict(lambda:collections.defaultdict(list)));by_mr=collections.defaultdict(lambda:collections.defaultdict(list));by_dataset=collections.defaultdict(lambda:collections.defaultdict(list));by_cell=collections.defaultdict(lambda:collections.defaultdict(list));failures=[];source_gold_disagreement=[];joint=collections.defaultdict(list)
for k in keys:
 a=answers[k['review_id']]
 assert type(a['label']) is int and a['label'] in [0,1,2]
 assert type(a['grammatical']) is bool and type(a['operation_valid']) is bool
 checks={'label':a['label']==k['expected_label'],'grammar':a['grammatical'],'operation':a['operation_valid']}
 if k['is_inv']:
  assert type(a['source_equivalent']) is bool;checks['inv_equivalence']=a['source_equivalent']
 for criterion,value in checks.items():
  all_values[criterion][k['version']].append(int(value))
  if k.get('paired',True):paired[criterion][(k['dataset'],k['pair_id'])][k['version']].append(int(value))
  if k['version']=='v3.4':
   by_mr[k['operation']][criterion].append(int(value));by_dataset[k['dataset']][criterion].append(int(value));by_cell[(k['dataset'],k['operation'])][criterion].append(int(value))
 joint[k['version']].append(int(all(checks.values())))
 record={**k,'premise':labels[k['review_id']]['premise'],'source_hypothesis':ops[k['review_id']]['source_hypothesis'],'hypothesis':labels[k['review_id']]['hypothesis'],'human_answers':a,'failed_criteria':[c for c,v in checks.items() if not v]}
 if not all(checks.values()):failures.append(record)
 if k['version']=='v3.4' and k['is_inv'] and a['source_equivalent'] and not checks['label']:source_gold_disagreement.append(record)
summary={}
for criterion,versions in all_values.items():
 counts=np.array([[sum(v['v3.3']),len(v['v3.3']),sum(v['v3.4']),len(v['v3.4'])] for v in paired[criterion].values()]);rng=np.random.default_rng(42);diffs=[]
 for _ in range(1500):
  c=counts[rng.integers(0,len(counts),len(counts))].sum(axis=0);diffs.append(c[2]/c[3]-c[0]/c[1])
 ci=np.quantile(diffs,[.025,.975]).tolist();old=float(np.mean(versions['v3.3']));new=float(np.mean(versions['v3.4']));paired_old=counts[:,0].sum()/counts[:,1].sum();paired_new=counts[:,2].sum()/counts[:,3].sum()
 summary[criterion]={'old_correct':sum(versions['v3.3']),'old_n':len(versions['v3.3']),'v3_3':old,'new_correct':sum(versions['v3.4']),'new_n':len(versions['v3.4']),'v3_4':new,'paired_old':float(paired_old),'paired_new':float(paired_new),'paired_difference_ci95':ci,'paired_source_groups':len(counts),'paired_units':int(counts[:,1].sum()),'absolute_95_percent_passed':new>=.95,'passes_all_existing_gates':bool(new>=.95 and new>=old and paired_new>=paired_old and ci[0]>=-.02)}
def summarize(groups):return {name:{criterion:{'correct':sum(v),'n':len(v),'rate':sum(v)/len(v)} for criterion,v in checks.items()} for name,checks in groups.items()}
# Poststratification is supplementary; existing gate remains the sampled-row metric.
population=collections.Counter()
for name,d in manifest['datasets'].items():
 rows,_=load_dataset(d['v3_4_path'])
 population.update((name,r['mr_id']) for r in rows if not is_source(r))
weighted={}
for criterion in summary:
 cells={cell:n for cell,n in population.items() if criterion!='inv_equivalence' or 'inv_equivalence' in by_cell[cell]}
 missing=[cell for cell in cells if not by_cell[cell].get(criterion)]
 weighted[criterion]={'population_rows':sum(cells.values()),'unreviewed_population_cells':[list(c) for c in missing],'point_estimate':None if missing else sum(n*np.mean(by_cell[cell][criterion]) for cell,n in cells.items())/sum(cells.values()),'formal_gate_metric':False,'description':'dataset x MR poststratified estimate for current 681-row development population, not observed population truth'}
result={'stage':'preliminary_human_answer_assessment','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'answer_path':str(ANSWERS),'answers_sha256':answer_sha,'packet_manifest_sha256':sha256(PACKET/'manifest.json'),'review_stage':manifest['stage'],'reviewer':supplied.get('reviewer'),'reviewer_present':bool(str(supplied.get('reviewer','')).strip()),'declared_human_attestation':supplied.get('human_attestation'),'answers_complete':True,'answers_count':len(keys),'new_review_units':138,'old_review_units':50,'paired_units':50,'new_only_units':88,'formal_assessment_accepted':formal_error is None,'formal_assessment_error':formal_error,'human_review_formally_complete':formal_error is None,'quality_passed':all(v['passes_all_existing_gates'] for v in summary.values()),'freeze_eligible':False,'all_metrics_below_absolute_gate':all(not v['absolute_95_percent_passed'] for v in summary.values()),'criteria':summary,'by_mr':summarize(by_mr),'by_dataset':summarize(by_dataset),'joint_pass':{v:{'correct':sum(a),'n':len(a),'rate':sum(a)/len(a)} for v,a in joint.items()},'poststratified_development_estimates':weighted,'inv_equivalent_but_human_label_differs_from_inherited_gold':len(source_gold_disagreement),'source_gold_disagreement_is_inference':True,'uncovered_MRs':[op for op,n in manifest['available_new_review_units_per_mr'].items() if not n],'extra_generation_recommended':False,'production_files_modified':False,'model_calls':0}
assert sha256(ANSWERS)==answer_sha
write_json(OUT/'preliminary_assessment.json',result);write_jsonl(OUT/'flagged_review_rows.jsonl',failures);write_jsonl(OUT/'inv_source_gold_disagreement_candidates.jsonl',source_gold_disagreement)
cn={'label':'标签正确','grammar':'语法合格','operation':'MR操作成立','inv_equivalence':'INV双向等价'}
lines=['# 人工答案检查：足以判断当前版本不通过质量门槛','','188/188条答案完整，ID无重复、遗漏或多余；标签与布尔字段类型正确，INV等价判断完整，盲审材料及对应数据文件哈希匹配。','答案human_attestation=true，但reviewer仍为空；现有正式评估器因此拒绝归档。本报告不虚构审核人，以下为据已填答案计算的初步统计，原答案文件未修改。','','## 样本质量统计','','以下为所审样本的结果，并非681条总体的真实精确错误率；按MR抽样且新旧MR组成不同，整体新旧均值不能作为纯因果比较。','','| 指标 | 本轮v3.4 | 历史参考v3.3 | 门槛 |','|---|---:|---:|---:|']
for c,v in summary.items():lines.append(f"| {cn[c]} | {v['new_correct']}/{v['new_n']} = {v['v3_4']:.2%} | {v['old_correct']}/{v['old_n']} = {v['v3_3']:.2%} | ≥95% |")
lines+=['','四项都未达到95%。历史INV只有1条参考，不足以证明INV质量不劣于旧版。','即使补齐reviewer，当前这些人工判断下的质量门槛仍不会通过。','','## 匹配来源的配对统计','','使用现有评估器同一来源组bootstrap方法，seed42、1500次，仅匹配的新旧单元参与配对差异。','','| 指标 | 配对旧／新 | 新减旧95% CI | 配对单元／来源组 |','|---|---|---|---|']
for c,v in summary.items():
 lo,hi=v['paired_difference_ci95'];lines.append(f"| {cn[c]} | {v['paired_old']:.2%}／{v['paired_new']:.2%} | {lo*100:.2f} 至 {hi*100:.2f} 个百分点 | {v['paired_units']}／{v['paired_source_groups']} |")
lines+=['','INV仅1个配对单元，其bootstrap区间不能反映未观察到的质量变化。','','## 按MR定位本轮问题','','| MR | 审核数 | 标签 | 语法 | 操作 | INV等价 |','|---|---:|---:|---:|---:|---:|']
for op,d in result['by_mr'].items():
 fmt=lambda c:f"{d[c]['rate']:.1%}" if c in d else '—'
 lines.append(f"| {op} | {d['label']['n']} | {fmt('label')} | {fmt('grammar')} | {fmt('operation')} | {fmt('inv_equivalence')} |")
lines+=['','从已标记样本可定位的修复方向：','- 添加／复合操作有直接拼接片段及连接词后错误大写等语言问题，例如“running in water and The dog …”。','- voice_switch包含“skateboards → Skateboarding is done …”这类名词化改写，虽可保义但不符合严格主动／被动转换；还会丢失限定语。','- 同义词替换没有稳定保持语境词义、固定搭配和严格双向等价；复合变换会叠加这些问题。','这些是对用户标记和对应文本的诊断，不是对人工答案的自动覆盖；未筛选、删除、修正标签或重写任何增强记录。','','## 数据总体加权敏感性检查','','抽样按MR和数据集平衡，未按实际行数比例抽样。补充按数据集×MR的总体行数后分层加权点估计，仅作敏感性检查，不替代既定验收。']
for c,v in weighted.items():lines.append(f"- {cn[c]}：{v['point_estimate']:.2%}（对应开发总体{v['population_rows']}行；非总体真值）。")
lines+=['',f"另有{len(source_gold_disagreement)}条新INV样本同时被标记为保义、但人工NLI标签不等于继承gold，提示原始gold或两阶段人工判断存在分歧。这是推断，需要单独复核，不能直接改原始标签或把所有差异都归因于增强。",'这些细节不改变目前四项质量指标不达门槛的结论。','','## 是否足够与下一步','','足够作为当前版本不应扩量的初步证据；不够作为通过质量验收、冻结提示词或开始正式生成的证据。','目前不建议为了达到900条而启动额外补齐预算；应先修复通用拼接／语法规则、voice资格与严格语义约束，再进行独立小样本复核，并重新检查低hypothesis-only accuracy是否伴随质量保持。','此前四个开发探针低于60%的结果仍为原始测量事实，但错误标签和生成退化可能影响其解释，不能据此宣布去捷径成功。','本材料是历史参考的初步盲审，未覆盖pronoun_substitution、conditional_clause，antonym仅1条，历史INV也仅1条；不替代后续匹配预算的对照或完整正式数据验收。','三轮提示词上限与既定预算仍保留；如后续需要新的语义提示词轮次或额外调用，应先由用户调整实验范围。','正式归档需审核人填写reviewer（姓名、用户名或稳定化名均可）；无需为得到当前不通过结论而立即扩大至每MR40条。']
(OUT/'REPORT_zh.md').write_text('\n'.join(lines)+'\n')
p=Path('/home/ubuntu/MTrain/local_runs/nli_v3_4_20261013_repair/GOAL_PROGRESS.json');progress=json.loads(p.read_text());progress.update(last_live_check_utc=result['created_utc'],last_turn_classification='progress_human_answers_assessed',consecutive_blocked_turns=0,human_answers_received=True,human_answers_path=str(ANSWERS),human_answers_sha256=answer_sha,human_review_formally_complete=formal_error is None,human_reviewer_identifier_missing=not result['reviewer_present'],human_review_preliminary_quality_passed=result['quality_passed'],human_review_assessment=str(OUT/'REPORT_zh.md'),budget_extension_recommended_after_human_review=False,goal_complete=False,blocking_condition='Supplied human review shows all four quality metrics below 95%; reviewer identity is missing for formal record. Additional generation alone is not a quality repair. Needs revised quality design before scaling.');write_json(p,progress)
print(json.dumps({'report':str(OUT/'REPORT_zh.md'),'criteria':summary,'joint_pass':result['joint_pass'],'poststratified_estimates':weighted,'source_gold_disagreements':len(source_gold_disagreement),'formal_error':formal_error},ensure_ascii=False))
