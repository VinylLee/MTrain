# 第三轮第二检查点诊断

固定600来源试验进行中的独立快照；不是完整训练／四测试验收。没有更改活跃代码快照、输入或生成行。

训练快照216行（120原始＋96增强）；仅使用hypothesis，在训练快照拟合词表、IDF和逻辑回归。SNLI快照107条增强、71个来源组，accuracy45.79%，来源组bootstrap 95% CI 36.36%–55.35%，多数标签基线39.25%。其余三个测试来源尚未生成，不能宣称四集通过。

|诊断来源|增强行|两模型标记行|
|---|---:|---:|
|train|96|21|
|snli|107|45|

两模型标记包括低概率、标签不一致、双向等价性疑点；不是人工错误率。原始分数单独保存，没有依此筛选、过滤或改标签。

待人工确认：train pair_id=74 synonym_replacement：`People practice maneuvers.` → `People execute maneuvers.`。两模型对某一方向预测非entailment；这只是设计诊断信号。

待人工确认：snli pair_id=1906 synonym_replacement：`A beagle runs in the grass.` → `A canine runs in the grass.`。两模型对某一方向预测非entailment；这只是设计诊断信号。

待人工确认：snli pair_id=7222 voice_switch：`Turtles are crawling in the green grass.` → `The grass is being crawled in by turtles.`。两模型对某一方向预测非entailment；这只是设计诊断信号。

后续仍需完成全部600来源、五个数据来源各180条增强配额、MR和INV占比检查，再确认固定探针四集结果及真实人工质量证据。当前不冻结，不启动生产，不增加第四轮提示词。
