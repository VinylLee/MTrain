"""Offline source/export/provenance audit, with unchanged saved Gemma verdict replay."""
from pathlib import Path
import collections,datetime,json,sys
sys.path.insert(0,'/home/ubuntu/MTrain')
from nli_v3_4 import core
from nli_v3_4.data import canonical_source,digest,is_source,load_dataset,normalize,sha256,source_uid,write_json
from nli_v3_4.recovery import OfflineClient,NeedsInference
from nli_v3_4.calls import validate_budget_reservation
ROOT=Path('/home/ubuntu/MTrain/local_runs/nli_v3_4_20261014_round3/pilot_round3_engineering_repair')
MANIFEST=Path('/home/ubuntu/MTrain/local_runs/nli_v3_4_20261012/development/manifest.json')
manifest=json.loads(MANIFEST.read_text());snapshot=json.loads((ROOT/'code_snapshot_manifest.json').read_text())
all_terminal='--all-terminal' in sys.argv
result={'stage':'development_structural_audit','checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'audited_datasets':['train','snli','mnlim','mnlimm'],'sick_generation_not_audited':not all_terminal,'actual_model_calls':0,'human_quality_verified':False,'full_target_verified':False,'datasets':{}}
if all_terminal:result['audited_datasets'].append('sick')
result['original_five_inputs_unchanged']=all(sha256(v['input'])==v['sha256'] for v in manifest['datasets'].values())
result['snapshot_files_checked']=len(snapshot['files'])
result['snapshot_changed_files']=[name for name,h in snapshot['files'].items() if sha256(ROOT/'code_snapshot'/name)!=h]
client=OfflineClient()
without_index=lambda row:{k:v for k,v in row.items() if k!='idx'}
for name in result['audited_datasets']:
 path=ROOT/'v3_4'/f'{name}.jsonl';journal=path.with_name(f'{name}.generation_log.jsonl');before={str(f):sha256(f) for f in [path,journal,path.with_suffix('.run.json')]}
 rows,sources=load_dataset(path);byid={s['pair_id']:canonical_source(s) for s in sources};meta=json.loads(path.with_suffix('.run.json').read_text());logs=[json.loads(s) for s in journal.read_text().splitlines() if s]
 _,raw_sources=load_dataset(manifest['datasets'][name]['input']);raw_byid={s['pair_id']:s for s in raw_sources}
 problems=[]
 if set(byid)!=set(manifest['datasets'][name]['development_pair_ids']):problems.append('source_cohort_mismatch')
 raw_differences=[s['pair_id'] for s in sources if without_index(s)!=without_index(raw_byid[s['pair_id']])]
 if raw_differences:problems.append('original_source_fields_differ_except_derived_idx')
 if len({r['request_id'] for r in logs})!=len(logs):problems.append('duplicate_request_id')
 accepted=[r for r in logs if r.get('row') is not None]
 follow=[r for r in rows if not is_source(r)]
 if collections.Counter(digest(without_index(r)) for r in follow)!=collections.Counter(digest(without_index(r['row'])) for r in accepted):problems.append('full_field_export_journal_multiset_mismatch')
 if name!='train' and [r['idx'] for r in rows]!=list(range(len(rows))):problems.append('noncontiguous_export_idx')
 expected=[source_uid(canonical_source(s)) for s in sorted(sources,key=lambda s:s['pair_id'])]
 if expected!=manifest['datasets'][name]['development_source_uids']:problems.append('source_uid_order_mismatch')
 replayed=0;inv_count=0;composite_count=0
 for entry in logs:
  source=byid[entry['pair_id']];op=entry['operation']
  if entry['source_uid']!=source_uid(source) or entry['request_id']!=digest([source_uid(source),op,entry['refill_round'],meta['seed'],meta['version']]):problems.append('request_identity_mismatch:'+entry['request_id']);continue
  if 'budget_reservation' in entry:validate_budget_reservation(entry,source,meta['seed'],meta['version'])
  row=entry.get('row')
  if row is None:continue
  if row['premise']!=source['premise'] or row['label']!=core.LABEL_IDS[core.target_label(source,op)] or row['mr_id']!=op or row['mr_type']!=core.OPERATION_SPECS[op]['mr_type']:problems.append('row_source_mr_label_binding_mismatch:'+entry['request_id'])
  if core.OPERATION_SPECS[op]['family']=='inv':
   inv_count+=1
   if row['label']!=source['label']:problems.append('invariant_changed_source_gold:'+entry['request_id'])
  if op in core.COMPOSITE_STAGE_PLANS:
   composite_count+=1
   if row.get('component_mrs')!=entry['trace'].get('applied_steps') or tuple(row.get('component_mrs',[])) not in core.COMPOSITE_STAGE_PLANS[op]:problems.append('ordered_composite_plan_mismatch:'+entry['request_id'])
  try:
   text,_=core.generate_one(client,source,op,meta['seed']+entry['refill_round'],entry['trace'])
   if text==row['hypothesis']:replayed+=1
   else:problems.append('cached_verdict_replay_text_mismatch:'+entry['request_id'])
  except Exception as exc:problems.append('cached_verdict_replay_'+type(exc).__name__+':'+entry['request_id'])
 if any(sha256(p)!=h for p,h in before.items()):problems.append('terminal_input_changed_during_audit')
 result['datasets'][name]={'sources':len(sources),'followups':len(follow),'invariant_followups':inv_count,'composite_followups':composite_count,'accepted_rows_revalidated_from_raw_cached_verdicts':replayed,'full_source_fields_differ_except_derived_idx':raw_differences,'label_quotas_satisfied':all(sum(r['label']==label for r in follow)==60 for label in range(3)),'input_sha256':before,'problems':problems,'structural_checks_passed':not problems}
result['structural_checks_passed']=result['original_five_inputs_unchanged'] and not result['snapshot_changed_files'] and all(d['structural_checks_passed'] for d in result['datasets'].values())
out=ROOT/('terminal_structure_audit_all_five' if all_terminal else 'terminal_structure_audit');write_json(out/'report.json',result)
lines=['# 已结束来源的结构与溯源检查','',('检查范围：五来源开发输出，共600原始来源。' if all_terminal else '检查范围：训练、SNLI、MNLI matched、MNLI mismatched开发输出。SICK仍在生成，未纳入本次增强行检查。'),'只重放已保存的生成响应与Gemma评审；实际模型调用为0，不使用DeBERTa或RoBERTa决定行有效性。','','| 来源 | 原始行 | 增强行 | INV／复合 | 原评审重放通过 | 结构通过 |','|---|---:|---:|---|---:|---|']
for name,d in result['datasets'].items():lines.append(f"| {name} | {d['sources']} | {d['followups']} | {d['invariant_followups']}／{d['composite_followups']} | {d['accepted_rows_revalidated_from_raw_cached_verdicts']} | {d['structural_checks_passed']} |")
lines+=['',f"五个原始输入文件哈希不变：{result['original_five_inputs_unchanged']}。执行快照共检查{result['snapshot_files_checked']}个文件，变化文件：{result['snapshot_changed_files']}。",'检查保留原始记录全部字段（测试导出idx为重新生成的连续索引）、导出与日志完整字段多重集、请求身份、MR标签绑定、INV继承原标签及有序复合轨迹。','结构通过与已有Gemma评审重放不等于真实人工语义质量通过；每来源180条目标没有全部满足，未验证四个完整正式测试集≤60%。']
(out/'REPORT_zh.md').write_text('\n'.join(lines)+'\n')
print(json.dumps({'structural_checks_passed':result['structural_checks_passed'],'snapshot_files_checked':result['snapshot_files_checked'],'datasets':{name:{k:v for k,v in d.items() if k not in ['input_sha256']} for name,d in result['datasets'].items()}},ensure_ascii=False))
