# 本地实现状态

本地提交 d5b3727，分支 feat/nli-shortcut-v3-4-local-20261012，未推送。
原有19个备份文件的哈希保持一致，包括旧数据、脚本和未提交修改。

固定主诊断基线：SNLI 96.02%，MNLI-m 90.23%，MNLI-mm 89.78%，SICK 92.74%。
主报告：baseline_logreg/REPORT_zh.md。110项单元测试通过。

DeBERTa和RoBERTa MNLI已实际运行开发诊断，输入未修改，无模型筛选或改标签。
环境、分数与修改依据见 design_environment.json、design_smoke_edit_plan、DESIGN_NOTES.json。
正式生成入口不依赖这两个模型。

固定调度后的首轮600来源组开发试验正在后台运行：pilot_round1/driver.json。
三个对照臂，每来源目标180条增强；两任务并发。完成后自动生成对照报告和人工盲审材料，
停止在人工审核，不自动冻结或开始全量生成。状态查询：

`python3 status_nli_v3_4.py --root local_runs/nli_v3_4_20261012/pilot_round1`

当前尚未验证四集≤60%，尚未完成正式v3.4数据，也未取得人工质量通过证据。
冻结及正式完成验证均拒绝缺失的证据。
