"""Offline guards and leakage tests for the new execution policy; no model API."""
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace

import pytest

ROOT=Path(__file__).resolve().parent


def module(name,filename):
    spec=importlib.util.spec_from_file_location(name,ROOT/filename)
    value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value


def test_policy_rejects_test_generation_before_loading_any_frozen_runner(tmp_path,monkeypatch):
    controller=module('train_only_control_test','run_train_first.py')
    monkeypatch.setattr(controller,'ROOT',tmp_path)
    for allowed,test_flag in [(['train','snli'],False),(['train'],True)]:
        (tmp_path/'TRAIN_FIRST_CONTROL.json').write_text(json.dumps({'allowed_generation_origins':allowed,'full_test_generation_allowed':test_flag}))
        with pytest.raises(ValueError,match='training generation only'):controller.frozen_training()


def test_terminal_training_goes_to_audit_and_never_calls_a_test_origin(tmp_path,monkeypatch):
    controller=module('train_only_sequence_test','run_train_first.py')
    monkeypatch.setattr(controller,'ROOT',tmp_path)
    (tmp_path/'full_for_inspection').mkdir();(tmp_path/'full_for_inspection/plan.json').write_text('{}')
    (tmp_path/'audit_training_first.py').write_text('# offline fake entrypoint\n')
    dispatched=[]
    def origin(plan,sources,name):
        dispatched.append(name);assert name=='train'
        return {'generation_complete':False,'audit':{'followups':17}}
    monkeypatch.setattr(controller,'frozen_training',lambda:(SimpleNamespace(run_origin=origin),{},[]))
    audits=[]
    monkeypatch.setattr(controller.subprocess,'run',lambda command,**kwargs:audits.append(command))
    controller.main()
    state=json.loads((tmp_path/'TRAIN_FIRST_RUN.json').read_text())
    assert dispatched==['train'] and len(audits)==1
    assert Path(audits[0][1]).name=='audit_training_first.py' and audits[0][-1]=='run'
    assert state['state']=='training_audit_finished_awaiting_user_review'
    assert state['full_test_generation_allowed'] is False and not state['training_generation_complete']


def synthetic():
    from nli_v3_4.data import export_source,export_followup
    result={v:[] for v in ('v3_3','v3_4')}
    for i in range(60):
        source={'pair_id':i,'label':i%3,'premise':'A person is outdoors.',
                'hypothesis':f'A person sees unique{i}.'}
        for version,verb in [('v3_3','notices'),('v3_4','observes')]:
            result[version].extend([export_source(source,'train'),
                export_followup(source,'synonym_replacement',f'A person {verb} unique{i}.',i%3,'inv',None,'train')])
    return result


def test_group_split_never_fits_heldout_unique_tokens_and_is_shared_across_versions(tmp_path,monkeypatch):
    audit=module('train_only_leakage_test','audit_training_first.py')
    original_fit=audit.fit_probe
    fits=[]
    def check_fit(rows):
        probe,iterations=original_fit(rows)
        ids={r['pair_id'] for r in rows}
        vocabulary=probe.named_steps['tfidf'].vocabulary_
        assert all(f'unique{i}' not in vocabulary for i in set(range(60))-ids)
        fits.append(ids);return probe,iterations
    monkeypatch.setattr(audit,'fit_probe',check_fit)
    result=audit.group_shortcuts(synthetic(),tmp_path)
    splits=json.loads((tmp_path/'splits.json').read_text())
    assert len(fits)==12
    for seed,split in splits.items():
        assert not set(split['training_pair_ids'])&set(split['heldout_pair_ids'])
        assert set(split['training_pair_ids'])|set(split['heldout_pair_ids'])==set(range(60))
        for cohort in ('full_available_training_cohort','common_source_MR_ordinal'):
            records=[r for r in result['records'] if r['seed']==int(seed) and r['cohort']==cohort]
            assert len(records)==2 and records[0]['heldout_augmented_rows']==records[1]['heldout_augmented_rows']==12


def test_quality_samples_are_deterministic_and_human_blind_packet_is_unfilled(tmp_path):
    audit=module('train_only_sampling_test','audit_training_first.py')
    data=synthetic();hashes={'v3_3':'old','v3_4':'new'}
    for folder in (tmp_path/'a',tmp_path/'b'):audit.sample_quality(data,folder,hashes)
    for name in ('nli_tasks.jsonl','quality_units.private.jsonl','human_review/label_grammar_blind.jsonl'):
        assert (tmp_path/'a'/name).read_bytes()==(tmp_path/'b'/name).read_bytes()
    answers=json.loads((tmp_path/'a/human_review/answers.template.json').read_text())
    assert answers['reviewer']=='' and answers['human_attestation'] is False
    assert all(r['label'] is None for r in answers['answers'])
    blind=[json.loads(line) for line in (tmp_path/'a/human_review/label_grammar_blind.jsonl').read_text().splitlines()]
    assert all(set(r)=={'review_id','premise','hypothesis'} for r in blind)
    sampling=json.loads((tmp_path/'a/sampling_manifest.json').read_text())
    assert sampling['neural_scores_used_for_sampling'] is False


def test_unscored_neural_outputs_are_not_coerced_to_quality_success():
    worker=module('train_only_neural_test','score_training_quality.py')
    unit={'row':{'label':0},'source':{'label':0},'tasks':{'pair':'p','source_pair':'s','inv_forward':'f','inv_reverse':'r'}}
    assert worker.unit_verdict(unit,{k:{'status':'too_long'} for k in 'psfr'})=={}
    scores={k:{'status':'scored','prediction':'entailment'} for k in 'psfr'}
    scores['r']['prediction']='neutral'
    assert worker.unit_verdict(unit,scores)['INV_bidirectional_entailment'] is False
