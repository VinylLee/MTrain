"""Run the unchanged, hash-bound v2 engine and its hypothesis-only diagnostic.

This is a run-local driver, not a prompt/acceptance implementation. The full-data
branch is for user inspection and never claims the old quality gate has passed.
"""
import argparse
from collections import Counter, defaultdict, deque
import fcntl
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
sys.path.insert(0, str(REPO))
from nli_v3_4 import core, workflow
from nli_v3_4.calls import _save
from nli_v3_4.data import (DATASETS, audit, canonical_source, digest, export_followup,
                         export_source, load_dataset, normalize, quotas, read_jsonl,
                         sha256, source_uid, write_jsonl)
from nli_v3_4.refinement import call_cap, token_cap
from nli_v3_4.refinement_v2 import DirectTypedEngine
from nli_v3_4.protocol import has_api_failure
from run_nli_quality_repair_pilot import BoundedRequestClient, frozen_sources

ENGINE = DirectTypedEngine()
EXPECTED = "9e1d983ab5ade3ae348fb89a921a279d352717c597d7027affaad87134ace0c4"
ORIGINS = ("train", *DATASETS)
MANIFEST = REPO/"local_runs/nli_v3_4_20261012/development/manifest.json"
PREVIOUS_PLAN = REPO/"local_runs/nli_v3_4_20261015_round4b_refinement/pilot_v2/plan.json"


def identities():
    original = json.loads(PREVIOUS_PLAN.read_text())
    assert ENGINE.fingerprint() == EXPECTED == original["contract_sha256"]
    assert ENGINE.contract() == original["contract"]
    assert all(sha256(REPO/p) == h for p,h in original["code_hashes"].items())
    return {**original["code_hashes"], str(Path(__file__).resolve()): sha256(__file__),
            "analysis/hypothesis_only_logreg.py": sha256(REPO/"analysis/hypothesis_only_logreg.py")}


def request_list(origin, sources, count):
    """Preselect from frozen sources without reading responses, review, or scores."""
    result = []
    uses = Counter()
    for refill in range(4):
        queues = workflow.scheduling_queues(sources, 42, refill, ENGINE)
        attempts = Counter()
        while any(q for ops in queues.values() for q in ops.values()):
            for label in range(3):
                ops = [op for op,q in queues[label].items() if q]
                if not ops:
                    continue
                op = min(ops, key=lambda op:(attempts[label,op], op))
                q = queues[label][op]
                s = min(q, key=lambda s:(uses[s["pair_id"]], digest([s["hypothesis"],op,42+refill])))
                q.remove(s)
                uses[s["pair_id"]] += 1
                attempts[label,op] += 1
                result.append({"request_id":digest([EXPECTED,origin,source_uid(s),op,42+refill]),
                    "dataset":origin,"pair_id":s["pair_id"],"source_uid":source_uid(s),
                    "operation":op,"seed":42+refill,"refill_round":refill,"target_label":label,
                    "max_calls":call_cap(op),"max_output_tokens":token_cap(op)})
                if len(result) == count:
                    return result
    return result


def prepare(stage):
    folder = ROOT/stage
    path = folder/"plan.json"
    if path.exists():
        return validate(stage)
    manifest, development = frozen_sources(MANIFEST)
    sources = development
    if stage == "full_for_inspection":
        screen = json.loads((ROOT/"screening_decision.json").read_text())
        if not screen.get("full_generation_authorized_by_screen"):
            raise ValueError("all-four shortcut screen has not passed")
        sources = {d:[canonical_source(s) for s in load_dataset(manifest['datasets'][d]['input'])[1]] for d in ORIGINS}
    targets = {d:30 if stage=="development_screen" else manifest['datasets'][d]['target_followups'] for d in ORIGINS}
    requests = {d:request_list(d,sources[d],300 if stage=="development_screen" else len(sources[d])*24) for d in ORIGINS}
    plan = {"kind":"unchanged_current_v2_shortcut_screen_and_inspection_v1", "stage":stage,
        "contract_sha256":EXPECTED,"contract":ENGINE.contract(),"code_hashes":identities(),
        "manifest":str(MANIFEST),"manifest_sha256":sha256(MANIFEST),
        "previous_plan":str(PREVIOUS_PLAN),"previous_plan_sha256":sha256(PREVIOUS_PLAN),
        "sources_sha256":{d:digest(sources[d]) for d in ORIGINS},
        "targets":targets,"requests":requests,"seed":42,"max_refill_rounds":4,
        "max_requests":sum(map(len,requests.values())),
        "max_model_calls":sum(r['max_calls'] for v in requests.values() for r in v),
        "max_output_tokens":sum(r['max_output_tokens'] for v in requests.values() for r in v),
        "base_url":"http://127.0.0.1:1234/v1", "max_workers":1,
        "selection":"fixed_label_MR_round_robin_with_source_reuse_balancing_before_inference",
        "quota_policy":"balanced_E_N_C_minimum_80_percent_INV",
        "external_nli_in_pipeline":False,"prompts_modified":False,
        "quality_passed":False,"production_quality_freeze":False,"remote_push":False,
        "full_scope":"all_original_sources_old_followup_count_replaced_current_engine_applicable_MRs_only",
        "authorization":"User: keep current prompts, test shortcuts, generate full data for inspection if all four pass"}
    if stage == "full_for_inspection":
        plan["screen_decision_sha256"] = sha256(ROOT/"screening_decision.json")
    plan["plan_fingerprint"] = digest(plan)
    _save(path,plan)
    return plan,sources


def validate(stage):
    plan = json.loads((ROOT/stage/"plan.json").read_text())
    original = dict(plan); fingerprint=original.pop("plan_fingerprint")
    if digest(original)!=fingerprint or identities()!=plan['code_hashes'] or sha256(MANIFEST)!=plan['manifest_sha256']:
        raise ValueError("frozen current plan/code/manifest changed")
    if sha256(PREVIOUS_PLAN)!=plan['previous_plan_sha256']:
        raise ValueError("original v2 identity changed")
    manifest,sources=frozen_sources(MANIFEST)
    if stage=="full_for_inspection":
        if sha256(ROOT/"screening_decision.json")!=plan['screen_decision_sha256']:
            raise ValueError("screen evidence changed")
        sources={d:[canonical_source(s) for s in load_dataset(manifest['datasets'][d]['input'])[1]] for d in ORIGINS}
    assert {d:digest(sources[d]) for d in ORIGINS}==plan['sources_sha256']
    for d in ORIGINS:
        expected=request_list(d,sources[d],300 if stage=="development_screen" else len(sources[d])*24)
        assert expected==plan['requests'][d]
    return plan,sources


def run_origin(plan,sources,origin):
    from openai import OpenAI
    stage=plan['stage']; out=ROOT/stage; journal=out/'journals'/f'{origin}.jsonl'
    if not journal.exists():
        journal.parent.mkdir(parents=True,exist_ok=True);journal.touch()
    entries=read_jsonl(journal)
    requests={r['request_id']:r for r in plan['requests'][origin]}
    if len({e['request_id'] for e in entries})!=len(entries):raise ValueError('duplicate request')
    by_id={s['pair_id']:s for s in sources}
    wanted=quotas(plan['targets'][origin]);minimum={l:wanted[l] if l==0 else int(__import__('math').ceil(.8*wanted[l])) for l in range(3)}
    accepted=[e['row'] for e in entries if e.get('row')]
    counts=Counter(r['label'] for r in accepted)
    inv=Counter(r['label'] for r in accepted if core.OPERATION_SPECS[r['mr_id']]['family']=='inv')
    seen={(normalize(s['premise']),normalize(s['hypothesis'])) for s in sources}
    seen.update((normalize(r['premise']),normalize(r['hypothesis'])) for r in accepted)
    for e in entries:
        assert e['request']==requests[e['request_id']]
        if e.get('row'):
            r=e['request'];s=by_id[r['pair_id']]
            assert ENGINE.replay_one(s,r['operation'],e['trace'],r['seed'])==e['row']['hypothesis']
    processed={e['request_id'] for e in entries}
    config={"stage":stage,"dataset":origin,"engine":"refinement_v2","contract_sha256":EXPECTED,
        "code_hashes":plan['code_hashes'],"manifest_sha256":plan['manifest_sha256'],
        "source_sha256":digest(sources),"plan_sha256":sha256(out/'plan.json'),
        "target_followups":plan['targets'][origin],"label_quotas":wanted,
        "minimum_invariant_counts":minimum,"external_nli_in_pipeline":False,
        "prompts_modified":False,"quality_passed":False,"production_quality_freeze":False}
    def checkpoint(state):
        grouped=defaultdict(list)
        for row in accepted:grouped[row['pair_id']].append(row)
        rows=[];schema='train' if origin=='train' else 'test'
        for s in sources:
            rows.append(export_source(s,schema));rows.extend(grouped[s['pair_id']])
        if schema=='test':
            for i,row in enumerate(rows):row['idx']=i
        path=out/'v3_4'/f'{origin}.jsonl';write_jsonl(path,rows)
        _save(path.with_suffix('.run.json'),config)
        ledger=list((out/'calls'/origin).glob('*/*.json'))
        report={**config,"state":state,"requests":len(entries),"calls":len(ledger),
            "completed":all(counts[l]==wanted[l] for l in range(3)),"audit":audit(rows),
            "generation_complete":all(counts[l]==wanted[l] for l in range(3)),
            "original_sources_retained":len(sources),"followup_labels":dict(counts),"invariant_counts":dict(inv)}
        _save(out/'reports'/f'{origin}.json',report)
        return report
    checkpoint('running')
    api=None;errors=0
    try:
        with journal.open('a') as handle:
            for r in plan['requests'][origin]:
                if r['request_id'] in processed:continue
                label=r['target_label'];op=r['operation'];is_inv=core.OPERATION_SPECS[op]['family']=='inv'
                if counts[label]>=wanted[label] or (not is_inv and counts[label]-inv[label]>=wanted[label]-minimum[label]):continue
                if api is None:api=OpenAI(base_url=plan['base_url'],api_key='local',timeout=120,max_retries=0)
                s=by_id[r['pair_id']];client=BoundedRequestClient(api,out/'calls'/origin/r['request_id'],r['max_calls'])
                text,trace=ENGINE.generate_one(client,s,op,r['seed'])
                entry={'request_id':r['request_id'],'request':r,'trace':trace,'row':None}
                if text:
                    assert ENGINE.replay_one(s,op,trace,r['seed'])==text
                    key=(normalize(s['premise']),normalize(text))
                    if key not in seen:
                        row=export_followup(s,op,text,label,core.OPERATION_SPECS[op]['mr_type'],trace.get('applied_steps'),'train' if origin=='train' else 'test')
                        entry['row']=row;accepted.append(row);seen.add(key);counts[label]+=1
                        if is_inv:inv[label]+=1
                    else:entry['discard_reason']='duplicate_or_unchanged'
                handle.write(json.dumps(entry,ensure_ascii=False)+'\n');handle.flush()
                __import__('os').fsync(handle.fileno());entries.append(entry);processed.add(r['request_id'])
                report=checkpoint('running')
                print(json.dumps({'dataset':origin,'requests':len(entries),'followups':len(accepted),'labels':dict(counts),'calls':report['calls']}),flush=True)
                errors=errors+1 if has_api_failure(trace) else 0
                if errors>=3:raise RuntimeError('three consecutive API failures')
                if all(counts[l]==wanted[l] for l in range(3)):break
    except BaseException:
        checkpoint('interrupted_or_failed');raise
    return checkpoint('complete' if all(counts[l]==wanted[l] for l in range(3)) else 'planned_requests_exhausted_partial')


def run_stage(stage):
    plan,sources=prepare(stage)
    folder=ROOT/stage
    with (folder/'run.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        reports={}
        for d in ORIGINS:reports[d]=run_origin(plan,sources[d],d)
        from analysis.hypothesis_only_logreg import run
        probe=folder/'hypothesis_only_logreg'
        metrics=None
        if all(reports[d]['audit']['followups'] for d in DATASETS):
            metrics=run(folder/'v3_4/train.jsonl',{d:folder/'v3_4'/f'{d}.jsonl' for d in DATASETS},probe) if not probe.exists() else json.loads((probe/'metrics.json').read_text())
        complete=all(r['generation_complete'] for r in reports.values())
        decision={'stage':stage,'contract_sha256':EXPECTED,'all_cohorts_complete':complete,
            'all_four_shortcut_pass':bool(metrics and set(metrics['evaluations'])==set(DATASETS) and metrics['all_datasets_pass']),
            'full_generation_authorized_by_screen':bool(stage=='development_screen' and complete and metrics and metrics['all_datasets_pass']),
            'metrics_path':str(probe/'metrics.json') if metrics else None,
            'quality_passed':False,'quality_review_complete':True,'quality_review_result':'previous_human_label_5_of_7_no_claim_of_quality_pass',
            'prompts_modified':False,'external_nli_in_pipeline':False,'remote_push':False,
            'full_is_for_user_inspection_not_quality_certification':True,'reports':reports}
        _save(ROOT/('screening_decision.json' if stage=='development_screen' else 'full_generation_status.json'),decision)
        return decision


def main():
    p=argparse.ArgumentParser();p.add_argument('command',choices=['prepare','run']);args=p.parse_args()
    if args.command=='prepare':
        plan,_=prepare('development_screen')
        print(json.dumps({k:plan[k] for k in ['contract_sha256','targets','max_requests','max_model_calls','max_output_tokens']}));return
    decision=run_stage('development_screen')
    print(json.dumps({'screen_complete':True,'all_four_shortcut_pass':decision['all_four_shortcut_pass'],
                      'full_generation_authorized_by_screen':decision['full_generation_authorized_by_screen']}),flush=True)
    if decision['full_generation_authorized_by_screen']:
        run_stage('full_for_inspection')


if __name__=='__main__':main()
