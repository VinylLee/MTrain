"""CPU-only comparative quality proxies on frozen samples; no generation/filter API."""
import argparse
from collections import defaultdict
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parents[1]))
from analysis.design_nli_quality import MODELS,score_tasks
from nli_v3_4.data import read_jsonl,sha256,write_json,write_jsonl

LABELS=('entailment','neutral','contradiction')


def rate_ci(values):
    import numpy as np
    if not values:return {'n_scored':0,'rate':None,'ci95_source_group_bootstrap':None}
    grouped=defaultdict(lambda:[0,0])
    for pid,value in values:
        grouped[pid][0]+=int(value);grouped[pid][1]+=1
    counts=np.asarray(list(grouped.values()));rng=np.random.default_rng(42)
    samples=[]
    for _ in range(1500):
        c=counts[rng.integers(0,len(counts),len(counts))].sum(axis=0);samples.append(c[0]/c[1])
    return {'n_scored':len(values),'source_groups':len(grouped),'rate':sum(v for _,v in values)/len(values),
        'ci95_source_group_bootstrap':np.quantile(samples,[.025,.975]).tolist()}


def unit_verdict(unit,predictions):
    answer={}
    def label(name):
        score=predictions[unit['tasks'][name]]
        return score.get('prediction') if score['status']=='scored' else None
    pair,source=label('pair'),label('source_pair')
    if pair is not None:answer['label_agreement']=pair==LABELS[unit['row']['label']]
    if source is not None:answer['original_gold_agreement']=source==LABELS[unit['source']['label']]
    if 'inv_forward' in unit['tasks']:
        forward,reverse=label('inv_forward'),label('inv_reverse')
        if forward is not None and reverse is not None:
            answer['INV_bidirectional_entailment']=forward==reverse=='entailment'
    return answer


def summarize(units,predictions):
    representatives={};per_mr={};matched={}
    for version in ('v3_3','v3_4'):
        group=[u for u in units if u['version']==version and u['representative']]
        criteria=defaultdict(list)
        for u in group:
            for k,v in unit_verdict(u,predictions).items():criteria[k].append((u['row']['pair_id'],v))
        representatives[version]={'n_selected':len(group),'criteria':{k:rate_ci(v) for k,v in criteria.items()}}
        per_mr[version]={}
        for mr in sorted({u['row']['mr_id'] for u in units if u['version']==version}):
            chosen=[u for u in units if u['version']==version and u['row']['mr_id']==mr]
            criteria=defaultdict(list)
            for u in chosen:
                for k,v in unit_verdict(u,predictions).items():criteria[k].append((u['row']['pair_id'],v))
            per_mr[version][mr]={'n_selected':len(chosen),'diagnostic_sample_not_population_weighted':True,
                'criteria':{k:rate_ci(v) for k,v in criteria.items()}}
        chosen=[u for u in units if u['version']==version and u['matched_appendix']]
        criteria=defaultdict(list)
        for u in chosen:
            for k,v in unit_verdict(u,predictions).items():criteria[k].append((u['row']['pair_id'],v))
        matched[version]={'n_selected':len(chosen),'criteria':{k:rate_ci(v) for k,v in criteria.items()}}
    return {'representative_sample':representatives,'matched_source_MR_appendix':matched,'per_MR_diagnostic_samples':per_mr}


def run(audit_root):
    import torch
    from transformers import AutoModelForSequenceClassification,AutoTokenizer
    audit_root=Path(audit_root);output=audit_root/'external_quality'
    if output.exists():raise FileExistsError('preserve the existing model audit')
    units=read_jsonl(audit_root/'quality_units.private.jsonl');raw_tasks=read_jsonl(audit_root/'nli_tasks.jsonl')
    tasks=[(r['task_id'],r['premise'],r['hypothesis']) for r in raw_tasks]
    task_ids=[r['task_id'] for r in raw_tasks]
    if len(task_ids)!=len(set(task_ids)):raise ValueError('duplicate frozen task IDs')
    inputs={str(audit_root/name):sha256(audit_root/name) for name in ('PLAN.json','quality_units.private.jsonl','nli_tasks.jsonl','sampling_manifest.json')}
    plan={'stage':'independent_post_generation_training_quality_proxies','models':MODELS,
        'device':'cpu','max_model_input_pairs':len(tasks)*len(MODELS),'inputs_sha256':inputs,
        'script_sha256':sha256(__file__),'generation_or_filtering_allowed':False,
        'source_data_relabeling_allowed':False,'human_quality_verified':False,
        'full_test_generation_allowed':False}
    write_json(output/'PLAN.json',plan)
    cache=Path.home()/'.cache/huggingface/hub';results={};metadata={}
    for name,(model_id,revision) in MODELS.items():
        snapshot=cache/('models--'+model_id.replace('/','--'))/'snapshots'/revision
        tokenizer=AutoTokenizer.from_pretrained(snapshot,local_files_only=True)
        model=AutoModelForSequenceClassification.from_pretrained(snapshot,local_files_only=True)
        model.eval()
        scores=score_tasks(model,tokenizer,tasks,'cpu',8)
        predictions=dict(zip(task_ids,scores))
        if len(predictions)!=len(tasks):raise ValueError('missing model task results')
        write_jsonl(output/f'{name}_scores.jsonl',[{'task_id':key,**score} for key,score in predictions.items()])
        results[name]=summarize(units,predictions)
        metadata[name]={'model_id':model_id,'revision':revision,'weights_sha256':sha256(snapshot/'model.safetensors'),
            'id2label':model.config.id2label,'scored_tasks':sum(v['status']=='scored' for v in scores),
            'too_long_tasks':sum(v['status']=='too_long' for v in scores)}
        write_json(output/'partial_summary.json',results)
        print(json.dumps({'quality_model_completed':name,'tasks':len(tasks)}),flush=True)
        del model,tokenizer
    if any(sha256(p)!=s for p,s in inputs.items()):raise ValueError('frozen quality audit inputs changed')
    write_json(output/'summary.json',{'models':metadata,'comparisons':results,
        'input_hashes_unchanged':True,'human_quality_verified':False,
        'quality_noninferiority_proven':False,'acceptance_filter_or_relabeling':False})
    lines=['# 独立 NLI 模型的训练数据质量对照','','这是模型一致性和 INV 双向蕴涵代理，不是人工正确率；模型分数不进入增强流水线，也不筛选或改写数据。代表抽样作为主表，MR 补样和共同来源/MR 另列，不能混合为总体比例。','','|模型|版本|代表样本|标签一致率|INV 双向蕴涵|','|---|---|---:|---:|---:|']
    for name,result in results.items():
        for version,r in result['representative_sample'].items():
            def text(criterion):
                x=r['criteria'].get(criterion,{})
                return f"{x['rate']:.2%} ({x['n_scored']})" if x.get('rate') is not None else '不可评估'
            lines.append(f"|{name}|{version}|{r['n_selected']}|{text('label_agreement')}|{text('INV_bidirectional_entailment')}|")
    lines+=['','summary.json 包含来源组 bootstrap 区间、原始 gold 一致性、共同来源/MR 附表及逐 MR 结果。未评分的超长输入单列，不强制赋标签。语法、完整 MR 语义和质量非劣仍需配套盲审，因此不自动宣布新数据质量不下降。']
    (output/'REPORT_zh.md').write_text('\n'.join(lines)+'\n')


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--audit-root',type=Path,required=True);a=p.parse_args();run(a.audit_root)
